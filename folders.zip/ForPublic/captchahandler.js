// Wait for the DOM content to be fully loaded before executing the script
document.addEventListener('DOMContentLoaded', () => {
    // Fetch the captcha data with difficulty level 3 and allow up to 3 fetch attempts
    fetchCaptchaData(3, 3);
});

function fetchCaptchaData(captchaNumber, fetchAttempts) {
    // Make a GET request to fetch captcha data from the server with the specified difficulty level
    fetch(`/captcha${captchaNumber}`)
        .then(response => {
            // Check if the response is not OK (status code not in the range 200-299)
            if (!response.ok) {
                throw new Error('Failed to fetch captcha data');
            }
            // Parse the response body as JSON
            return response.json();
        })
        .then(captchaData => {
            // Select the captcha image element by its ID
            const captchaImage = document.getElementById('captcha-image');
            // Set the source of the captcha image to the base64-encoded image data received from the server
            captchaImage.src = `data:image/jpeg;base64,${captchaData.image}`;

            // Store the hashed captcha answer in a global variable
            window.captchaAnswerHashed = captchaData.hashed_answer;

            // Add an event listener for form submission
            document.getElementById('captcha-form').addEventListener('submit', event => {
                // Prevent the default form submission behavior
                event.preventDefault();

                // Get the user's answer from the input field
                const userAnswer = document.getElementById('captcha-answer').value;

                // Hash the user's answer using SHA256
                const hashedUserAnswer = CryptoJS.SHA256(userAnswer).toString();

                // Compare the hashed user's answer with the hashed answer from the server
                if (hashedUserAnswer === window.captchaAnswerHashed) {
                    // If the answers match, clear the input field and redirect to the main page
                    document.getElementById('captcha-answer').value = ""; // clear entry
                    window.location.href = 'index.html';
                } else {
                    // If the answers do not match, create a toast message to notify the user
                    const toast = document.createElement('div');
                    toast.classList.add('toast');
                    toast.textContent = 'Incorrect Answer. Please try again.';
                    document.body.appendChild(toast);
                
                    // Fade out the toast message after a short delay
                    setTimeout(() => {
                        toast.classList.add('fade-out');
                    }, 500);

                    // Remove the toast message after the fade-out transition ends
                    setTimeout(() => {
                        toast.remove();
                    }, 2000);
                }
            });
        })
        .catch(error => {
            // Log the error to the console
            console.error('Error:', error);

            // If there are fetch attempts left, recursively call fetchCaptchaData with decremented attempts
            if (fetchAttempts > 0) {
                fetchCaptchaData(captchaNumber, fetchAttempts - 1)
            } else {
                // If no attempts are left, redirect to the landing page
                window.location.href = 'landing.html';
            }
        });
}
